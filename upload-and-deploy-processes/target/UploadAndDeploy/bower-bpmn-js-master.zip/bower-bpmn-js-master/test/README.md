# bower-bpmn-js integration tests

This project contains the integration tests for the bpmn-js bower bundle.


## Run tests

```
rm -rf bower_components && bower install
```

Serve this directory via a web server.

Inspect the test site at `http://localhost:9292/app/index.html`.